// Clean JS for tabla-verdad.html
(function(){
    document.addEventListener('DOMContentLoaded', function(){
        var input = document.getElementById('tt-expr');
        var btnGen = document.getElementById('tt-generate');
        var btnClear = document.getElementById('tt-clear');
        var btnBack = document.getElementById('tt-back');
        var resultDiv = document.getElementById('tt-result');
        var varBtns = Array.prototype.slice.call(document.querySelectorAll('.var-btn'));
        var opBtns = Array.prototype.slice.call(document.querySelectorAll('.op-btn'));
        var specialBtns = Array.prototype.slice.call(document.querySelectorAll('.special-btn'));

        function insert(text){
            try{
                var start = (typeof input.selectionStart === 'number') ? input.selectionStart : input.value.length;
                var end = (typeof input.selectionEnd === 'number') ? input.selectionEnd : start;
                input.value = input.value.slice(0, start) + text + input.value.slice(end);
                input.selectionStart = input.selectionEnd = start + text.length;
                input.focus();
            }catch(e){ input.value += text; }
        }

        varBtns.forEach(function(b){ b.addEventListener('click', function(){ insert(b.dataset.insert || b.textContent); }); });
        opBtns.forEach(function(b){ b.addEventListener('click', function(){ insert(b.dataset.insert || b.textContent); }); });
        specialBtns.forEach(function(b){ b.addEventListener('click', function(){ insert(b.dataset.insert || b.textContent); }); });

        if (btnClear) btnClear.addEventListener('click', function(){ input.value=''; resultDiv.innerHTML=''; input.focus(); });
        if (btnBack) btnBack.addEventListener('click', function(){ input.value = input.value.slice(0,-1); input.focus(); });
        if (btnGen) btnGen.addEventListener('click', function(){ run(); });
        if (input) input.addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); run(); } });

        function parseToAST(expr){
            var s = (expr||'').toUpperCase().replace(/\s+/g,'');
            var i = 0;
            function peek(){ return s[i]; }
            function consume(){ return s[i++]; }
            function parseExpression(){ return parseOr(); }
            function parseOr(){ var node = parseAnd(); while(peek() === '+'){ consume(); var right = parseAnd(); node = {type:'or', left:node, right:right}; } return node; }
            function parseAnd(){ var node = parseUnary(); while(true){ if (peek() === '·'){ consume(); var r = parseUnary(); node = {type:'and', left:node, right:r}; continue; } if (peek() && /[A-Z(]/.test(peek())){ var rr = parseUnary(); node = {type:'and', left:node, right:rr}; continue; } break; } return node; }
            function parseUnary(){ var node = parsePrimary(); while(peek() === "'"){ consume(); node = {type:'not', child: node}; } return node; }
            function parsePrimary(){ var ch = peek(); if (!ch) return {type:'const', value:false}; if (ch === '('){ consume(); var node = parseExpression(); if (peek() === ')') consume(); return node; } if (/[A-Z]/.test(ch)){ var v = consume(); return {type:'var', name: v}; } consume(); return {type:'const', value:false}; }
            var ast = parseExpression(); return ast;
        }

        function astToString(node){
            if (!node) return '';
            if (node.type === 'var') return node.name;
            if (node.type === 'const') return node.value ? '1' : '0';
            if (node.type === 'not') return '(' + astToString(node.child) + ")'";
            if (node.type === 'and') return '(' + astToString(node.left) + '·' + astToString(node.right) + ')';
            if (node.type === 'or') return '(' + astToString(node.left) + '+' + astToString(node.right) + ')';
            return '';
        }

        function collectSubexprs(node, list, seen){
            if (!node) return;
            if (node.type === 'var' || node.type === 'const') return;
            if (node.type === 'not'){ collectSubexprs(node.child, list, seen); var s = astToString(node); if (!seen.has(s)){ seen.add(s); list.push({node: node, text: s}); } return; }
            collectSubexprs(node.left, list, seen); collectSubexprs(node.right, list, seen); var s = astToString(node); if (!seen.has(s)){ seen.add(s); list.push({node: node, text: s}); }
        }

        function evalNode(node, vals){
            if (!node) return false;
            switch(node.type){
                case 'var': return !!vals[node.name];
                case 'const': return !!node.value;
                case 'not': return !evalNode(node.child, vals);
                case 'and': return evalNode(node.left, vals) && evalNode(node.right, vals);
                case 'or': return evalNode(node.left, vals) || evalNode(node.right, vals);
                default: return false;
            }
        }

        function getVariables(expr){
            var s = (expr||'').toUpperCase().replace(/\s+/g,'');
            var set = {};
            var m; var re = /[A-Z]/g;
            while ((m = re.exec(s)) !== null){ set[m[0]] = true; }
            return Object.keys(set).sort();
        }

        function generateTruthTableWithSteps(expr){
            var vars = getVariables(expr);
            var n = vars.length;
            if (n === 0) return {variables: [], steps: [], rows: []};
            if (n > 12) throw new Error('Demasiadas variables (máx 12)');
            var ast = parseToAST(expr);
            var subexprList = [];
            collectSubexprs(ast, subexprList, new Set());
            var finalText = astToString(ast);
            if (!subexprList.some(function(s){ return s.text === finalText; })) subexprList.push({node: ast, text: finalText});
            var stepTexts = subexprList.map(function(x){ return x.text; });
            var rows = [];
            for (var i=0;i<(1<<n);i++){
                var vals = {};
                for (var j=0;j<n;j++) vals[vars[j]] = !!( (i >> (n-1-j)) & 1 );
                var stepValues = [];
                for (var k=0;k<subexprList.length;k++){ var v = evalNode(subexprList[k].node, vals) ? 1 : 0; stepValues.push(v); }
                var row = vars.map(function(v){ return vals[v] ? 1 : 0; }).concat(stepValues);
                rows.push(row);
            }
            return {variables: vars, steps: stepTexts, rows: rows};
        }

        function renderTableWithSteps(obj){
            if (!obj || !obj.variables) { resultDiv.innerHTML = '<div style="color:#a00">No hay variables válidas</div>'; return; }
            var vars = obj.variables; var steps = obj.steps || []; var rows = obj.rows;
            var html = '<div class="tt-wrapper"><table class="tt-table"><thead><tr>';
            for (var i=0;i<vars.length;i++) html += '<th>' + vars[i] + '</th>';
            for (var s=0;s<steps.length;s++) html += '<th style="white-space:nowrap">' + steps[s] + '</th>';
            html += '<th>F</th></tr></thead><tbody>';
            for (var r=0;r<rows.length;r++){
                html += '<tr>';
                for (var c=0;c<rows[r].length;c++) html += '<td>' + rows[r][c] + '</td>';
                var final = rows[r][rows[r].length-1];
                html += '<td><b>' + final + '</b></td>';
                html += '</tr>';
            }
            html += '</tbody></table></div>';
            resultDiv.innerHTML = html;
        }

        if (btnGen){ btnGen.addEventListener('click', function(){ var expr = input.value || ''; if (!expr.trim()){ alert('Ingresa una expresión'); return; } try{ var table = generateTruthTableWithSteps(expr); renderTableWithSteps(table); } catch(e){ alert('Error: ' + (e && e.message ? e.message : e)); } }); }

        if (input && !input.value) input.value = "A'B + C";
        if (input && btnGen) { btnGen.click(); }
    });
})();
