// simplificacion.js — DEPRECADO
// Esta aplicación ahora utiliza iframes integrados que apuntan a calculadoras externas.
// El fichero local se mantiene (vacío) para evitar errores si alguna página sigue incluyendo el script.
// Si deseas eliminarlo completamente del repositorio, dime y lo haré (verificando referencias).

