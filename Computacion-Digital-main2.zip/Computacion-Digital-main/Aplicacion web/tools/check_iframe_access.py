import sys
import urllib.request
import urllib.error

URLS = [
    'https://calculadorasonline.com/calculadora-mapa-de-karnaugh-online/',
    'https://www.emathhelp.net/calculators/discrete-mathematics/boolean-algebra-calculator/'
]

for url in URLS:
    print('='*80)
    print('URL:', url)
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (compatible; Check/1.0)'
        })
        with urllib.request.urlopen(req, timeout=10) as resp:
            code = resp.getcode()
            headers = resp.getheaders()
            print('HTTP status:', code)
            # Look for common frame-blocking headers
            for name, value in headers:
                if name.lower() in ('x-frame-options', 'content-security-policy', 'server'):
                    print(f'{name}: {value}')
            # print a short snippet
            body = resp.read(800).decode('utf-8', errors='replace')
            print('\n--- body snippet ---\n')
            print(body[:600].replace('\n', ' '))
    except urllib.error.HTTPError as e:
        print('HTTPError:', e.code, e.reason)
        if e.headers:
            for name in ('X-Frame-Options', 'Content-Security-Policy'):
                if name in e.headers:
                    print(f'{name}:', e.headers[name])
    except Exception as e:
        print('Error fetching URL:', repr(e))

print('\nDone')
