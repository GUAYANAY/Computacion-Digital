﻿"""api-boole.py  DEPRECATED

Este archivo contenía un pequeño backend Flask para ofrecer endpoints de simplificación.
La aplicación ahora utiliza herramientas externas embebidas (iframes) para simplificación y mapas.

Conservaré este archivo como marcador (orquestación desactivada). Si quieres eliminarlo
completamente del repositorio, dime y lo haré.
"""

def main():
    print('api-boole.py: deprecated placeholder (endpoints removed).')

if __name__ == '__main__':
    main()
